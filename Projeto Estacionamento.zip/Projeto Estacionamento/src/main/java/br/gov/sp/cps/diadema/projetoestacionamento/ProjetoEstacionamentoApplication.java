package br.gov.sp.cps.diadema.projetoestacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class ProjetoEstacionamentoApplication {
    @GetMapping("/")
    public String Inicial(){
        return "Página Inicial";
    }
    public static void main(String[] args) {
        SpringApplication.run(ProjetoEstacionamentoApplication.class, args);
    }

}